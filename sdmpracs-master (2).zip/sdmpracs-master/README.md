# sdmpracs
Practicals for the Species Distribution Modeling class 

We will work through each practical exercise during class and you will then replicate a similar flow with your data as homework. 
The aim is for you to complete an SDM analysis and evaluation using your data by the end of the practical sessions. You will present this as a 5 minute presentation in one of the last two weeks of class. 
